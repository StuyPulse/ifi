#ifndef _TRAJ_NULL_H
#define _TRAJ_NULL_H


void init_null(void);

#endif
