#include "trajectory.h"
trajectory traj_array[NUM_TRAJ];

void init_traj()
{
	init_straight_nogyro();
	init_turn();
}

